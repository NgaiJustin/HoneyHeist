/*******************************************************************************
 * Copyright 2011 See AUTHORS file.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

// WMW2: This class is (mostly) unmodified from com.badlogic.gdx.backends.lwjgl.audio;

package edu.cornell.gdiac.backend.audio;

import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.GdxRuntimeException;
import com.badlogic.gdx.utils.StreamUtils;

import java.io.*;

/**
 * Input Stream to read WAV Files
 *
 * @author Nathan Sweet
 */
public class WavInputStream extends FilterInputStream {

    public int channels, sampleRate, dataRemaining;

    public WavInputStream (FileHandle file) {
        super(file.read());
        try {
            if (read() != 'R' || read() != 'I' || read() != 'F' || read() != 'F')
                throw new GdxRuntimeException("RIFF header not found: " + file);

            skipFully(4);

            if (read() != 'W' || read() != 'A' || read() != 'V' || read() != 'E')
                throw new GdxRuntimeException("Invalid wave file header: " + file);

            int fmtChunkLength = seekToChunk('f', 'm', 't', ' ');

            // http://www-mmsp.ece.mcgill.ca/Documents/AudioFormats/WAVE/WAVE.html
            // http://soundfile.sapp.org/doc/WaveFormat/
            int type = read() & 0xff | (read() & 0xff) << 8;
            if (type != 1) {
                String name;
                switch (type) {
                    case 0x0002:
                        name = "ADPCM";
                        break;
                    case 0x0003:
                        name = "IEEE float";
                        break;
                    case 0x0006:
                        name = "8-bit ITU-T G.711 A-law";
                        break;
                    case 0x0007:
                        name = "8-bit ITU-T G.711 u-law";
                        break;
                    case 0xFFFE:
                        name = "Extensible";
                        break;
                    default:
                        name = "Unknown";
                }
                throw new GdxRuntimeException("WAV files must be PCM, unsupported format: " + name + " (" + type + ")");
            }

            channels = read() & 0xff | (read() & 0xff) << 8;
            if (channels != 1 && channels != 2) throw new GdxRuntimeException("WAV files must have 1 or 2 channels: " + channels);

            sampleRate = read() & 0xff | (read() & 0xff) << 8 | (read() & 0xff) << 16 | (read() & 0xff) << 24;

            skipFully(6);

            int bitsPerSample = read() & 0xff | (read() & 0xff) << 8;
            if (bitsPerSample != 16) throw new GdxRuntimeException("WAV files must have 16 bits per sample: " + bitsPerSample);

            skipFully(fmtChunkLength - 16);

            dataRemaining = seekToChunk('d', 'a', 't', 'a');
        } catch (Throwable ex) {
            StreamUtils.closeQuietly(this);
            throw new GdxRuntimeException("Error reading WAV file: " + file, ex);
        }
    }

    private int seekToChunk (char c1, char c2, char c3, char c4) throws IOException {
        while (true) {
            boolean found = read() == c1;
            found &= read() == c2;
            found &= read() == c3;
            found &= read() == c4;
            int chunkLength = read() & 0xff | (read() & 0xff) << 8 | (read() & 0xff) << 16 | (read() & 0xff) << 24;
            if (chunkLength == -1) throw new IOException("Chunk not found: " + c1 + c2 + c3 + c4);
            if (found) return chunkLength;
            skipFully(chunkLength);
        }
    }

    private void skipFully (int count) throws IOException {
        while (count > 0) {
            long skipped = in.skip(count);
            if (skipped <= 0) throw new EOFException("Unable to skip.");
            count -= skipped;
        }
    }

    public int read (byte[] buffer) throws IOException {
        if (dataRemaining == 0) return -1;
        int offset = 0;
        do {
            int length = Math.min(super.read(buffer, offset, buffer.length - offset), dataRemaining);
            if (length == -1) {
                if (offset > 0) return offset;
                return -1;
            }
            offset += length;
            dataRemaining -= length;
        } while (offset < buffer.length);
        return offset;
    }

}